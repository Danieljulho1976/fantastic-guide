import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Equipment from './pages/Equipment';
import Employees from './pages/Employees';
import ServiceOrders from './pages/ServiceOrders';

function App() {
  return (
    <Router>
      <div className="flex">
        <Sidebar />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/equipamentos" element={<Equipment />} />
            <Route path="/funcionarios" element={<Employees />} />
            <Route path="/ordens" element={<ServiceOrders />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;