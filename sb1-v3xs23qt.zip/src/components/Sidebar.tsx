import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Wrench, Users, FileText } from 'lucide-react';

const Sidebar = () => {
  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: Wrench, label: 'Equipamentos', path: '/equipamentos' },
    { icon: Users, label: 'Funcionários', path: '/funcionarios' },
    { icon: FileText, label: 'Ordens de Serviço', path: '/ordens' },
  ];

  return (
    <div className="w-64 min-h-screen bg-white border-r border-gray-200 p-4">
      <h1 className="text-xl font-bold mb-8 px-4">Manutenção Preventiva</h1>
      <nav>
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center space-x-3 px-4 py-3 rounded-lg mb-2 ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-700 hover:bg-gray-50'
              }`
            }
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;