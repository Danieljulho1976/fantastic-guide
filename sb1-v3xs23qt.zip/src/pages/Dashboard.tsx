import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import {
  Wrench,
  Users,
  FileText,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import DashboardCard from '../components/DashboardCard';

const Dashboard = () => {
  // Mock data - will be replaced with real data from Supabase
  const stats = {
    equipmentCount: 5,
    employeeCount: 2,
    pendingOrders: 0,
    completedOrders: 2,
    delayedOrders: 1,
  };

  const pieData = [
    { name: 'Concluído', value: 66.7 },
    { name: 'Em Andamento', value: 33.3 },
  ];

  const COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444'];

  const recentOrders = [
    {
      id: 1,
      equipment: 'QUADRO ELÉTRICO',
      employee: 'DOUGLAS',
      date: '13/03/2025',
      status: 'in_progress',
    },
    {
      id: 2,
      equipment: 'QUADRO ELÉTRICO',
      employee: 'DOUGLAS',
      date: '13/03/2025',
      status: 'completed',
    },
    {
      id: 3,
      equipment: 'TANQUE DE OXIGÊNIO - REGIONAL',
      employee: 'DOUGLAS',
      date: '13/03/2025',
      status: 'completed',
    },
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <DashboardCard
          title="Equipamentos"
          value={stats.equipmentCount}
          icon={Wrench}
        />
        <DashboardCard
          title="Funcionários"
          value={stats.employeeCount}
          icon={Users}
        />
        <DashboardCard
          title="Ordens Pendentes"
          value={stats.pendingOrders}
          icon={FileText}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-semibold mb-4">
            Status das Ordens de Serviço
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Ordens Recentes</h2>
          <div className="space-y-4">
            {recentOrders.map((order) => (
              <div
                key={order.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div>
                  <h3 className="font-medium">{order.equipment}</h3>
                  <p className="text-sm text-gray-500">{order.employee}</p>
                  <p className="text-sm text-gray-500">
                    Agendado para: {order.date}
                  </p>
                </div>
                <div>
                  {order.status === 'completed' ? (
                    <span className="flex items-center text-green-600">
                      <CheckCircle size={16} className="mr-1" />
                      Concluído
                    </span>
                  ) : (
                    <span className="flex items-center text-blue-600">
                      <AlertTriangle size={16} className="mr-1" />
                      Em Progresso
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;