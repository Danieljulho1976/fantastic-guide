import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { PlusCircle, Pencil, Trash2, CheckCircle, AlertTriangle } from 'lucide-react';

interface ServiceOrder {
  id: string;
  order_number: string;
  equipment_id: string;
  maintenance_type_id: string;
  assigned_to: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  scheduled_date: string;
  completion_date?: string;
  completion_notes?: string;
  equipment: {
    name: string;
  };
  employees: {
    name: string;
  };
  maintenance_types: {
    name: string;
  };
}

interface Equipment {
  id: string;
  name: string;
}

interface Employee {
  id: string;
  name: string;
}

interface MaintenanceType {
  id: string;
  name: string;
}

const ServiceOrders = () => {
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [maintenanceTypes, setMaintenanceTypes] = useState<MaintenanceType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<ServiceOrder>>({});
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    fetchServiceOrders();
    fetchEquipment();
    fetchEmployees();
    fetchMaintenanceTypes();
  }, []);

  const fetchServiceOrders = async () => {
    const { data, error } = await supabase
      .from('service_orders')
      .select(`
        *,
        equipment:equipment_id(name),
        employees:assigned_to(name),
        maintenance_types:maintenance_type_id(name)
      `)
      .order('scheduled_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching service orders:', error);
      return;
    }
    
    setOrders(data || []);
  };

  const fetchEquipment = async () => {
    const { data, error } = await supabase
      .from('equipment')
      .select('id, name')
      .order('name');
    
    if (error) {
      console.error('Error fetching equipment:', error);
      return;
    }
    
    setEquipment(data || []);
  };

  const fetchEmployees = async () => {
    const { data, error } = await supabase
      .from('employees')
      .select('id, name')
      .order('name');
    
    if (error) {
      console.error('Error fetching employees:', error);
      return;
    }
    
    setEmployees(data || []);
  };

  const fetchMaintenanceTypes = async () => {
    const { data, error } = await supabase
      .from('maintenance_types')
      .select('id, name')
      .order('name');
    
    if (error) {
      console.error('Error fetching maintenance types:', error);
      return;
    }
    
    setMaintenanceTypes(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const orderData = {
      ...formData,
      order_number: formData.order_number || generateOrderNumber(),
    };

    if (editingId) {
      const { error } = await supabase
        .from('service_orders')
        .update(orderData)
        .eq('id', editingId);
      
      if (error) {
        console.error('Error updating service order:', error);
        return;
      }
    } else {
      const { error } = await supabase
        .from('service_orders')
        .insert([orderData]);
      
      if (error) {
        console.error('Error creating service order:', error);
        return;
      }
    }
    
    setIsModalOpen(false);
    setFormData({});
    setEditingId(null);
    fetchServiceOrders();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service order?')) return;
    
    const { error } = await supabase
      .from('service_orders')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting service order:', error);
      return;
    }
    
    fetchServiceOrders();
  };

  const handleEdit = (order: ServiceOrder) => {
    setFormData(order);
    setEditingId(order.id);
    setIsModalOpen(true);
  };

  const generateOrderNumber = () => {
    const date = new Date();
    const year = date.getFullYear();
    const random = Math.floor(Math.random() * 100000).toString().padStart(5, '0');
    return `${random}/${year}`;
  };

  const getStatusBadge = (status: ServiceOrder['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="flex items-center text-green-600">
            <CheckCircle size={16} className="mr-1" />
            Completed
          </span>
        );
      case 'in_progress':
        return (
          <span className="flex items-center text-blue-600">
            <AlertTriangle size={16} className="mr-1" />
            In Progress
          </span>
        );
      case 'cancelled':
        return (
          <span className="flex items-center text-red-600">
            <Trash2 size={16} className="mr-1" />
            Cancelled
          </span>
        );
      default:
        return (
          <span className="flex items-center text-yellow-600">
            <AlertTriangle size={16} className="mr-1" />
            Pending
          </span>
        );
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Service Orders</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
        >
          <PlusCircle size={20} />
          New Service Order
        </button>
      </div>

      <div className="bg-white rounded-lg shadow">
        <table className="min-w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left p-4">Order Number</th>
              <th className="text-left p-4">Equipment</th>
              <th className="text-left p-4">Type</th>
              <th className="text-left p-4">Assigned To</th>
              <th className="text-left p-4">Scheduled Date</th>
              <th className="text-left p-4">Status</th>
              <th className="text-left p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-b hover:bg-gray-50">
                <td className="p-4">{order.order_number}</td>
                <td className="p-4">{order.equipment?.name}</td>
                <td className="p-4">{order.maintenance_types?.name}</td>
                <td className="p-4">{order.employees?.name}</td>
                <td className="p-4">
                  {new Date(order.scheduled_date).toLocaleDateString()}
                </td>
                <td className="p-4">{getStatusBadge(order.status)}</td>
                <td className="p-4">
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(order)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Pencil size={20} />
                    </button>
                    <button
                      onClick={() => handleDelete(order.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
            <h2 className="text-xl font-bold mb-4">
              {editingId ? 'Edit Service Order' : 'New Service Order'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Equipment
                </label>
                <select
                  value={formData.equipment_id || ''}
                  onChange={(e) =>
                    setFormData({ ...formData, equipment_id: e.target.value })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Equipment</option>
                  {equipment.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Maintenance Type
                </label>
                <select
                  value={formData.maintenance_type_id || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      maintenance_type_id: e.target.value,
                    })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Type</option>
                  {maintenanceTypes.map((type) => (
                    <option key={type.id} value={type.id}>
                      {type.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Assign To
                </label>
                <select
                  value={formData.assigned_to || ''}
                  onChange={(e) =>
                    setFormData({ ...formData, assigned_to: e.target.value })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Employee</option>
                  {employees.map((employee) => (
                    <option key={employee.id} value={employee.id}>
                      {employee.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Scheduled Date
                </label>
                <input
                  type="datetime-local"
                  value={formData.scheduled_date?.slice(0, 16) || ''}
                  onChange={(e) =>
                    setFormData({ ...formData, scheduled_date: e.target.value })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Status
                </label>
                <select
                  value={formData.status || 'pending'}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      status: e.target.value as ServiceOrder['status'],
                    })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
              {formData.status === 'completed' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Completion Notes
                  </label>
                  <textarea
                    value={formData.completion_notes || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        completion_notes: e.target.value,
                      })
                    }
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    rows={3}
                  />
                </div>
              )}
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setFormData({});
                    setEditingId(null);
                  }}
                  className="px-4 py-2 text-gray-700 hover:text-gray-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingId ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceOrders;