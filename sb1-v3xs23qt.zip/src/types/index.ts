export interface Equipment {
  id: string;
  name: string;
  model: string;
  serialNumber: string;
  location: string;
  lastMaintenance: Date;
  nextMaintenance: Date;
  notes: string;
}

export interface Employee {
  id: string;
  name: string;
  workload: string;
  department: string;
}

export interface ServiceOrder {
  id: string;
  orderNumber: string;
  creationDate: Date;
  equipmentId: string;
  preventionType: string;
  employeeId: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  checklist: Record<string, any>;
  completionNotes?: string;
  completionDate?: Date;
}

export interface DashboardStats {
  equipmentCount: number;
  employeeCount: number;
  pendingOrders: number;
  completedOrders: number;
  delayedOrders: number;
}