/*
  # Insert Maintenance Types and Checklists

  1. New Data
    - Air Conditioning Monthly Maintenance
    - Electrical Panel Monthly Maintenance
    - Generator Daily Inspection
    - Pump Daily Inspection
    
  2. Checklist Items
    - All required checklist items for each maintenance type
*/

-- Insert maintenance types
INSERT INTO maintenance_types (id, name, description, frequency) VALUES
  (
    'ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0',
    'Preventiva Mensal de Ar Condicionado',
    'Manutenção preventiva mensal em equipamentos de ar condicionado',
    'monthly'
  ),
  (
    'bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1',
    'Preventiva Mensal de Quadros Elétricos',
    'Manutenção preventiva mensal em quadros elétricos',
    'monthly'
  ),
  (
    'cc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b2',
    'Ronda Diária de Geradores',
    'Inspeção diária de geradores',
    'daily'
  ),
  (
    'dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3',
    'Ronda Diária de Bombas de Recalque',
    'Inspeção diária de bombas de recalque',
    'daily'
  );

-- Insert checklist items for Air Conditioning
INSERT INTO checklist_items (maintenance_type_id, description, item_order, response_type, required) VALUES
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Limpeza do filtro de ar', 1, 'yes_no_na', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Verificação de vazamentos de gás refrigerante', 2, 'yes_no_na', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Lubrificação dos componentes mecânicos', 3, 'yes_no_na', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Verificação do sistema elétrico', 4, 'yes_no_na', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Verificação da pressão do sistema', 5, 'numeric', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Verificação da temperatura de saída de ar', 6, 'numeric', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Verificação do controle remoto', 7, 'yes_no_na', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Verificação do sistema de dreno', 8, 'yes_no_na', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Medir TENSÃO(V) do Equipamento', 9, 'numeric', true),
  ('ac6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b0', 'Medir CORRENTE (A) do Equipamento', 10, 'numeric', true);

-- Insert checklist items for Electrical Panels
INSERT INTO checklist_items (maintenance_type_id, description, item_order, response_type, required) VALUES
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Limpeza geral do gabinete', 1, 'yes_no_na', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Verificar se o quadro possui tranca ou cadeado na porta', 2, 'yes_no_na', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Realizar reaperto de possível', 3, 'yes_no_na', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Tensão entre Fases (RS)', 4, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Tensão entre Fases (RT)', 5, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Tensão entre Fases (ST)', 6, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Tensão Fase/Neutro (RN)', 7, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Tensão Fase/Neutro (SN)', 8, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Tensão Fase/Neutro (TN)', 9, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Corrente (Fase R)', 10, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Corrente (Fase S)', 11, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Corrente (Fase T)', 12, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Medição de Tensão Fase/Terra', 13, 'numeric', true),
  ('bc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b1', 'Verificar sinais de aquecimento', 14, 'yes_no_na', true);

-- Insert checklist items for Generators
INSERT INTO checklist_items (maintenance_type_id, description, item_order, response_type, required) VALUES
  ('cc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b2', 'Nível do óleo diesel (litros)', 1, 'numeric', true),
  ('cc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b2', 'Tensão da bateria (V)', 2, 'numeric', true),
  ('cc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b2', 'Nível do óleo lubrificante', 3, 'multiple_choice', true),
  ('cc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b2', 'Nível da água do radiador', 4, 'multiple_choice', true),
  ('cc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b2', 'Funcionamento do sistema de pré-aquecimento', 5, 'multiple_choice', true);

-- Insert checklist items for Pumps
INSERT INTO checklist_items (maintenance_type_id, description, item_order, response_type, required) VALUES
  ('dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3', 'Verificar pontos de vazamento na bomba/tubulações', 1, 'yes_no_na', true),
  ('dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3', 'Bomba em uso', 2, 'multiple_choice', true),
  ('dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3', 'Condições gerais do quadro elétrico', 3, 'yes_no_na', true),
  ('dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3', 'Corrente Fase R (A)', 4, 'numeric', true),
  ('dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3', 'Corrente Fase S (A)', 5, 'numeric', true),
  ('dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3', 'Corrente Fase T (A)', 6, 'numeric', true);

-- Update options for multiple choice items
UPDATE checklist_items 
SET options = '["OK", "NOK"]'
WHERE maintenance_type_id = 'cc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b2' 
AND response_type = 'multiple_choice';

UPDATE checklist_items 
SET options = '["BOMBA 01", "BOMBA 02"]'
WHERE maintenance_type_id = 'dc6a7e7a-c6a9-4c1f-8f7d-d3f2d7e8c9b3' 
AND description = 'Bomba em uso';